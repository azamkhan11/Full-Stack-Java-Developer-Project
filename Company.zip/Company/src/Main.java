public class Main {

    public static void main(String[] args) {
         System.out.println("Application Name :- LockedMe.com");
        System.out.println("Developer Name :- Azam Khan");

        LockedMe lockedMe = new LockedMe();
        lockedMe.option();
    }
}